import argparse, glob, csv, re, os, gzip, shutil
from argparse import RawTextHelpFormatter
from Bio import SeqIO

parser = argparse.ArgumentParser(formatter_class=RawTextHelpFormatter)

parser.add_argument("-i", "--inputVcfDirectory", help='Path to the vcf input directory (required).', required=True)
parser.add_argument("-o", "--outputName", help='File name of the ouput vcf file.', default='result.vcf')
parser.add_argument("-b", "--bamDirectory", help='Path to the bamfiles directory (required).', required = True)
parser.add_argument("-g", "--gtf", help= 'Path to the input gtf file (required).', required = True)
parser.add_argument("-f", "--fasta", help= 'Path to the input fasta file (required).', required = True)

args = parser.parse_args()

def step1(outputDirectory, inputDirectory, outputFile):
	print("Starting Step 1")
	print("\tInput Directory: " + inputDirectory)
	print("\tOutput File Name: " + outputFile)

	if os.path.exists(inputDirectory):
    		f = glob.glob(inputDirectory+'*.vcf')
    		with open(outputDirectory+outputFile,'w') as wfd:
        		with open(f[0],'r') as fin:
            			for line in fin:
                			if line.startswith('#CHROM'):
                    				wfd.write(line)
        		for x in f[1:]:
            			with open(x,'r') as fin:
                			for line in fin:
                    				if not line.startswith('#'):
                        				wfd.write(line)

def step2(outputFile, outputDirectory):
	print("Starting Step 2")
	print("\tVcf File Location: " + outputFile)
	print("\tBedfiles Directory: " + outputDirectory)

	num_sample=0
	bed=[]

	try:
    		input = open(outputFile, "r")
	except (OSError, IOError) as e:
    		print("####ERROR:can not load vcf file "+outputFile)
    		raise Exception(e)

	for line in input:
    		if line.startswith("##"):
        		continue
    		elif line.startswith("#CHROM"):
        		samples=line.split("\t")
        		num_sample=len(samples)-9
        		print("There are "+ str(num_sample)+ " samples in " + outputFile+"\n")
        		for i in range(9, len(samples)):
            			filename=samples[i]+".bed"
            			output_bed=open(outputDirectory+filename, "w")
            			bed.append(output_bed)
        		continue
  
    		words=line.strip("\n").split("\t")
    		for i in range(9, len(words)):
        		tokens=words[i].split(":")
        		dp=0
        		if len(tokens) > 1:
            			dp_field=tokens[1].split(",")
            			if len(dp_field) >1:
                			dp=int(dp_field[0])+int(dp_field[1])
        		if tokens[0] =="0/0" or tokens[0]=="./." or dp <10:
            			continue
        		bed[i-9].write(words[0]+"\t"+words[1]+"\n")

def step3(bam, bed, output, step):
	print("Starting Step 3")
	print("\tBamfile Directory: " + bam)
	print("\tBedfile Directory: " + bed)
	print("\tOutput Pileup Directory: " + output)
	os.system('/usr/bin/Rscript final.r ' + bam + ' ' + bed + ' ' + output + ' '+ step)

def step4(pileup):
	print("Starting Step 4")
	print("\tPileup Directory: " + pileup)

	gg=glob.glob(pileup+"*.pileup")
	for x in gg:
		f=open(x, "r")
		output = open(x+"ref", "w")
		output.write("chr\tpos\tA\tT\tC\tG\ta\tt\tc\tg\n")
		next(f)
		l = f.readline()
		words=l.strip("\n").split("\t")
		key0=words[0]+"_"+words[1]

		A,C,T,G,a,c,t,g = [0 for _ in range(8)]

		if words[3]=="A" and words[2]=="+":
			A=words[4]
		elif words[3]=="A" and words[2]=="-":
			a=words[4]
		elif words[3]=="T" and words[2]=="+":
			T=words[4]
		elif words[3]=="T" and words[2]=="-":
			t=words[4]
		elif words[3]=="C" and words[2]=="+":
			C=words[4]
		elif words[3]=="C" and words[2]=="-":
			c=words[4]
		elif words[3]=="G" and words[2]=="+":
			G=words[4]
		elif words[3]=="G" and words[2]=="-":
			g=words[4]

		for line in f:
			words=line.strip("\n").split("\t")
			key1=words[0]+"_"+words[1]
    
			if key1==key0:
				if words[3]=="A" and words[2]=="+":
					A=words[4]
				elif words[3]=="A" and words[2]=="-":
					a=words[4]
				elif words[3]=="T" and words[2]=="+":
					T=words[4]
				elif words[3]=="T" and words[2]=="-":
					t=words[4]
				elif words[3]=="C" and words[2]=="+":
					C=words[4]
				elif words[3]=="C" and words[2]=="-":
					c=words[4]
				elif words[3]=="G" and words[2]=="+":
					G=words[4]
				elif words[3]=="G" and words[2]=="-":
					g=words[4]
                   
			else:
				tokens=key0.split("_")
				output.write(tokens[0]+"\t"+ tokens[1]+"\t"+str(A)+"\t"+str(T)+"\t"+str(C)+"\t"+str(G)+"\t"+str(a)+"\t"+str(t)+"\t"+str(c)+"\t"+str(g)+'\n')
				A,C,T,G,a,c,t,g = [0 for _ in range(8)]

					#words=line.strip("\n").split("\t")
					#key0=words[0]+"_"+words[1]
				key0=key1
				if words[3]=="A" and words[2]=="+":
					A=words[4]
				elif words[3]=="A" and words[2]=="-":
					a=words[4]
				elif words[3]=="T" and words[2]=="+":
					T=words[4]
				elif words[3]=="T" and words[2]=="-":
					t=words[4]
				elif words[3]=="C" and words[2]=="+":
					C=words[4]
				elif words[3]=="C" and words[2]=="-":
					c=words[4]
				elif words[3]=="G" and words[2]=="+":
					G=words[4]
				elif words[3]=="G" and words[2]=="-":
					g=words[4]

		output.write(words[0]+"\t"+ words[1]+"\t"+str(A)+"\t"+str(T)+"\t"+str(C)+"\t"+str(G)+"\t"+str(a)+"\t"+str(t)+"\t"+str(c)+"\t"+str(g) + '\n') 

def step5(pileup, gtf):
	print("Starting Step 5")
	print("\tPileup Directory: " + pileup)
	print("\tGtf file location: " + gtf)

	cols = dict()    
	gg = glob.glob(pileup+'*.pileupref')
	for x in gg:
		with open(x+"orm",'w') as fout:
			with open(x,'r') as fin:
				for line in fin:
					b = line.split('\t')
					cols[b[0]+'_'+b[1]]=line.strip("\n")
                
			with open(gtf, 'r') as f:
				for line in f:
					line= line.rstrip(os.linesep)
					if not line.startswith('#!'):
						lss=line.split('\t')
						if lss[2] == "gene":
							for i in range(int(lss[3]), int(lss[4])+1):
								tokens=lss[8].split(";")
								gene_name=tokens[1].split('\"')
								gene_name=gene_name[1]
								key=lss[0].lstrip(' ')+"_"+str(i)
								if key in cols.keys():
									fout.write(cols[key]+"\t"+gene_name+"\t"+lss[6]+"\n")

def step6(pileup, fasta):
	print("Starting Step 6")
	print("\tPileup Directory: " + pileup)
	print("\tFasta file location: " + fasta)
	seqs = list(SeqIO.parse(fasta, "fasta"))

	def get_chr(c):
		if c=="X":
			return 23
		elif c=="Y":
			return 24
		elif c=="M":
			return 25
		else:
			return int(c)

	gg=glob.glob(pileup+"*.pileupreform")
	for x in gg:
		output = open(x+"at", 'w')
		positions = open (x, "r")
		output.write("chr\tpos\tref\tA\tT\tC\tG\ta\tt\tc\tg\tgene\tstrand\n")
		for line in positions:
			words=line.strip().split("\t")
			newwords = "\t".join(words[2:])
			chrs=get_chr(words[0])
			p=int(words[1])
			if p>len(seqs[chrs-1]):
				continue
			s=seqs[chrs-1].seq[p-1]
			output.write(str(chrs)+"\t"+str(p)+"\t"+s+"\t"+newwords+"\n")
		output.close()

def step7(pileup):
	print("Starting Step 7")
	print("\tPileup Directory: " + pileup)

	gg=glob.glob(pileup+"*.pileupreformat")
	for x in gg:
		with open(x, "r") as f:
			with open(x+".sum1", "w") as output:
				output.write("Chr\tpos\tref_alt\ttr\tntr\tgene\tstrand\n")
				header = next(f)

				tr,ntr = [0 for _ in range(2)]
				ref_alt=""
				list1 = []
				prev_line=''
				for line in f:
					if line != prev_line:
						w=line.strip().split("\t")
						key1=w[11]+"_"+w[12]

						if w[12] == "+":
							list1 = w[3:7]
							maxNumber = list1[0]
							maxIndex = 0 
							for index, number in enumerate(list1):
								if int(number) > int(maxNumber):
									maxIndex = index
									maxNumber = number
              
							if maxIndex == 0:
								ref_alt=w[2]+"->A"
								tr=w[3]
								ntr=w[7]
							elif maxIndex == 1:
								ref_alt=w[2]+"->T"
								tr=w[4]
								ntr=w[8]
							elif maxIndex == 2:
								ref_alt=w[2]+"->C"
								tr=w[5]
								ntr=w[9]
							elif maxIndex == 3:
								ref_alt=w[2]+"->G"
								tr=w[6]
								ntr=w[10]

						else:

							tr=0
							ntr=0
							ref_alt=""
							list1 = []
 
							list1 = w[7:11]
							maxNumber = list1[0]
							maxIndex = 0
							for index, number in enumerate(list1):
								if int(number) > int(maxNumber):
									maxIndex = index
									maxNumber = number
							if maxIndex == 0:
								ref_alt=w[2]+"->A"
								tr=w[7]
								ntr=w[3]
							elif maxIndex == 1:
								ref_alt=w[2]+"->T"
								tr=w[8]
								ntr=w[4]
							elif maxIndex == 2:
								ref_alt=w[2]+"->C"
								tr=w[9]
								ntr=w[5]
							elif maxIndex == 3:
								ref_alt=w[2]+"->G"
								tr=w[10]
								ntr=w[6]
					prev_line = line
					output.write(str(w[0])+"\t"+str(w[1])+"\t"+str(ref_alt)+"\t"+str(tr)+"\t"+str(ntr)+"\t"+str(w[11])+"\t"+ str(w[12])+'\n')

def step8(pileup):
	print("Starting Step 8")
	print("\tPileup Directory: " + pileup)

	gg=glob.glob(pileup + "*.sum1")
	for x in gg:
		f=open(x, "r")
		output = open(x+".sum2", "w")
		output.write("Ref_alt\tTr\tNtr\n")
		next(f)
		l = f.readline()
		words=l.strip("\n").split("\t")
		key0=words[2]

		totaltr,totalntr= [0 for _ in range(2)]

		for line in sorted(f, key=lambda line: line.split()[2]):
			words=line.strip("\n").split("\t")
			key1=words[2]

			if key1==key0:
				totaltr += int(words[3])
				totalntr += int(words[4])

			else:
				output.write(key0+"\t"+ str(totalntr)+"\t"+str(totaltr)+'\n')

				totaltr,totalntr = [0 for _ in range(2)]
				key0=key1
				totaltr += int(words[3])
				totalntr += int(words[4])
		output.write(key1+"\t"+ str(totalntr)+"\t"+str(totaltr)+'\n') 
def step9(pileup, outputDirectory):
	print("Starting Step 9")
	print("\tPileup Directory: " + pileup)
	print("\tOutput Directory: " + outputDirectory)
	os.system('/usr/bin/Rscript final.r ' + pileup + ' ' + outputDirectory + ' filler 9')

def step10(output):
	print("Creating markdown summary")
	print("\tFile Location: " + output)
	os.system('/usr/bin/Rscript final.r ' + output + ' filler filler 10')
path= os.getcwd()

step1(path, args.inputVcfDirectory, args.outputName)

bedpath = path + '/bedfiles/'
if not os.path.exists(bedpath):
	os.mkdir(bedpath)
step2(path + '/' + args.outputName, bedpath) 

ppath= path + '/pileups/'
if not os.path.exists(ppath):
	os.mkdir(ppath)
step3(args.bamDirectory, bedpath, ppath, "3")
shutil.rmtree(bedpath)

step4(ppath)

step5(ppath, args.gtf)

step6(ppath, args.fasta)

step7(ppath)

step8(ppath)

outpath= path + '/output/'
if not os.path.exists(outpath):
	os.mkdir(outpath)
step9(ppath, outpath)
shuil.rmtree(ppath)
step10(outpath)
