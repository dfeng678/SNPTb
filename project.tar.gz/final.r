#!/usr/bin/env Rscript
args <- commandArgs(trailingOnly=TRUE)
step=strtoi(args[4])
if (step == 3) {
Bampath= args[1]
Bedpath= args[2]
Outpath= args[3]
setwd(Outpath)

library(Rsamtools)
files_bam = list.files(path = Bampath, pattern="\\.bam$", full.names = T)
files_bed = list.files(path = Bedpath, pattern="\\.bed$", full.names = T)

for (i in 1:length(files_bam)){
    bamFile <- files_bam[i]
    bedfiles <- read.csv(files_bed[i], sep="\t", header=F)
    seqnames <- as.character(bedfiles[,1])
    starts <- ends <- bedfiles[,2]
    ranges=IRanges(starts,ends)
    w <- GRanges(seqnames,ranges)
    param <- ScanBamParam(which=w)
    res <- pileup(bamFile,scanBamParam=param)
    sp <- unlist(strsplit(files_bed[i], '/'))
    name <- sp[length(sp)]
    finalname <- paste0(Outpath,name)
    filename <- paste0(sub('\\.bed$', '', finalname), ".pileup")
    write.table(res, filename, row.names=F,sep='\t',quote =F)
}
} else if (step==9){
#!/usr/bin/env Rscript
Inputpath= args[1]
Outpath= args[2]
setwd(Outpath)

 library(reshape2)
 library(ggplot2)
 
 files_freq = list.files(path = Inputpath, pattern="\\.sum2$", full.names = T)
 files_fr = list.files(path = Inputpath, pattern="\\.sum1$", full.names = T)
 
 for (i in 1:length(files_freq)){
   a <- read.table(files_freq[i], header=T)
   a =a[-1,]
   
   xx = read.table(files_fr[i], header=T)
   yy = xx[,3:5]
   yy = yy[order(yy$ref_alt),]
   zz =melt(yy)
   x = split(zz, zz$ref_alt)
   if (any(sapply(x,nrow) < 4)){ 
	y = x[-which(sapply(x, nrow) < 4)]
	} else {
		y=x
	}

   tests <- lapply(y, function(y) t.test(value ~ variable, y))
   g = sapply(tests, "[[", "p.value")
   
   a <- a[which(a$Ref_alt %in% names(g)),]
   a$pval  <- lapply(g, round, 2)
   a$Ref_alt = paste(a$Ref_alt," ", "(p=",a$pval, ")")
   
   df <- melt(a[,-4])
   x = sub('\\.pileupreformat.sum1.sum2$', '', basename(files_freq[i]))
   png(file = paste0(x,'.png'))
   print(ggplot(df, aes(factor(Ref_alt), value, fill = variable)) + geom_bar(stat="identity", position = "dodge") +scale_fill_brewer(palette = "Set1") +
           theme_bw() + labs(x="", y="", title=files_freq[i]) + theme(legend.position="top",axis.title.x=element_blank(), axis.text.x = element_text(angle=90)))
   sink(paste0(x,'.csv'))
   print(df)
   sink()
   dev.off()
   #if (file.exists(fn)) file.remove(fn)
 } 
} else if (step==10){
rmarkdown::render('project.Rmd')
}
